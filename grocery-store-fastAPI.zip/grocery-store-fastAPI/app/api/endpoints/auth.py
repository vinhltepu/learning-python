from fastapi import APIRouter, Depends, HTTPException, Header, Request
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app import models
from app.schemas.user import UserLogin, Token, RefreshToken
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token
)

router = APIRouter()

# Trang đăng nhập
@router.get("/login", include_in_schema=False)
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={}
    )

# API đăng nhập, trả về access token và refresh token
@router.post("/login", response_model=Token)
def login(
    user: UserLogin,
    db: Session = Depends(get_db)
):

    db_user = db.query(models.User).filter(
        models.User.username == user.username
    ).first()

    if not db_user:
        raise HTTPException(
            status_code=400,
            detail="Tên đăng nhập không đúng"
        )

    if db_user.password != user.password:
        raise HTTPException(
            status_code=400,
            detail="Mật khẩu không đúng"
        )

    access_token = create_access_token(
        {
            "sub": db_user.username,
            "role": db_user.role
        }
    )

    refresh_token = create_refresh_token(
        {
            "sub": db_user.username
        }
    )

    return Token(
        access_token=access_token,
        refresh_token=refresh_token
    )


# refresh token
@router.post("/refresh", response_model=Token)
def refresh(
    token: RefreshToken,
    db: Session = Depends(get_db)
):

    payload = decode_token(token.refresh_token)

    if payload is None:
        raise HTTPException(
            status_code=401,
            detail="Refresh Token không hợp lệ"
        )

    username = payload["sub"]

    user = db.query(models.User).filter(
        models.User.username == username
    ).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User không tồn tại"
        )

    access_token = create_access_token(
        {
            "sub": user.username,
            "role": user.role
        }
    )

    refresh_token = create_refresh_token(
        {
            "sub": user.username
        }
    )

    return Token(
        access_token=access_token,
        refresh_token=refresh_token
    )

# đăng xuất (chỉ xóa token ở phía client, server không lưu token)
@router.post("/logout")
def logout():

    return {
        "message": "Đăng xuất thành công"
    }


# thông tin user hiện tại
@router.get("/me")
def me(
    authorization: str = Header(...)
):

    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Token không hợp lệ"
        )

    token = authorization.replace("Bearer ", "")

    payload = decode_token(token)

    if payload is None:
        raise HTTPException(
            status_code=401,
            detail="Token hết hạn hoặc không hợp lệ"
        )

    return payload